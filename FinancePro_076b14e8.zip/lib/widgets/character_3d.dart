import 'dart:math' as math;
import 'package:flutter/material.dart';

/// A stylized 3D-look character illustration built with pure Flutter (no assets).
/// Meant to evoke the "3D business man" from the reference video while remaining
/// asset-free so it always renders. Replace with a proper PNG/Rive/Lottie file
/// by dropping it into `assets/images/character.png` and using `Image.asset`.
class Character3D extends StatefulWidget {
  final double height;
  const Character3D({super.key, this.height = 280});

  @override
  State<Character3D> createState() => _Character3DState();
}

class _Character3DState extends State<Character3D>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 4))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final bob = math.sin(_c.value * 2 * math.pi) * 6;
        return Transform.translate(
          offset: Offset(0, bob),
          child: SizedBox(
            height: widget.height,
            child: CustomPaint(
              painter: _CharacterPainter(),
              child: const SizedBox.expand(),
            ),
          ),
        );
      },
    );
  }
}

class _CharacterPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;

    // Shadow beneath
    final shadow = Paint()
      ..color = Colors.black.withOpacity(0.35)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, h - 8), width: w * 0.55, height: 14),
      shadow,
    );

    // Body (suit jacket)
    final jacketPaint = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFEDEDED), Color(0xFFB8B8B8)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(cx - w * 0.28, h * 0.45, w * 0.56, h * 0.4));
    final jacketPath = Path()
      ..moveTo(cx - w * 0.22, h * 0.5)
      ..quadraticBezierTo(cx, h * 0.42, cx + w * 0.22, h * 0.5)
      ..lineTo(cx + w * 0.26, h * 0.82)
      ..quadraticBezierTo(cx, h * 0.86, cx - w * 0.26, h * 0.82)
      ..close();
    canvas.drawPath(jacketPath, jacketPaint);

    // Shirt V
    final shirtPaint = Paint()..color = Colors.white;
    final shirtPath = Path()
      ..moveTo(cx - w * 0.06, h * 0.48)
      ..lineTo(cx, h * 0.62)
      ..lineTo(cx + w * 0.06, h * 0.48)
      ..close();
    canvas.drawPath(shirtPath, shirtPaint);

    // Tie
    final tiePaint = Paint()..color = const Color(0xFF3B6FE0);
    final tiePath = Path()
      ..moveTo(cx - 6, h * 0.5)
      ..lineTo(cx + 6, h * 0.5)
      ..lineTo(cx + 4, h * 0.56)
      ..lineTo(cx + 10, h * 0.78)
      ..lineTo(cx, h * 0.82)
      ..lineTo(cx - 10, h * 0.78)
      ..lineTo(cx - 4, h * 0.56)
      ..close();
    canvas.drawPath(tiePath, tiePaint);

    // Trousers
    final trouserPaint = Paint()..color = const Color(0xFF2B2F45);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(cx - w * 0.09, h * 0.94),
          width: w * 0.14,
          height: h * 0.18,
        ),
        const Radius.circular(8),
      ),
      trouserPaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(cx + w * 0.09, h * 0.94),
          width: w * 0.14,
          height: h * 0.18,
        ),
        const Radius.circular(8),
      ),
      trouserPaint,
    );

    // Shoes
    final shoePaint = Paint()..color = Colors.white;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx - w * 0.09, h * 1.01),
        width: w * 0.18,
        height: 14,
      ),
      shoePaint,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx + w * 0.09, h * 1.01),
        width: w * 0.18,
        height: 14,
      ),
      shoePaint,
    );

    // Head
    final headPaint = Paint()
      ..shader = const RadialGradient(
        colors: [Color(0xFFFFE0BD), Color(0xFFDFB68C)],
      ).createShader(Rect.fromCircle(center: Offset(cx, h * 0.32), radius: w * 0.16));
    canvas.drawCircle(Offset(cx, h * 0.32), w * 0.15, headPaint);

    // Hair
    final hairPaint = Paint()..color = const Color(0xFFC28E4A);
    final hairPath = Path()
      ..moveTo(cx - w * 0.15, h * 0.28)
      ..quadraticBezierTo(cx - w * 0.16, h * 0.18, cx, h * 0.17)
      ..quadraticBezierTo(cx + w * 0.18, h * 0.18, cx + w * 0.14, h * 0.3)
      ..quadraticBezierTo(cx + w * 0.08, h * 0.22, cx, h * 0.22)
      ..quadraticBezierTo(cx - w * 0.1, h * 0.22, cx - w * 0.15, h * 0.28)
      ..close();
    canvas.drawPath(hairPath, hairPaint);

    // Beard
    final beardPaint = Paint()..color = const Color(0xFFC28E4A);
    canvas.drawArc(
      Rect.fromCircle(center: Offset(cx, h * 0.35), radius: w * 0.13),
      0.2,
      math.pi - 0.4,
      false,
      Paint()
        ..color = const Color(0xFFC28E4A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5,
    );

    // Eyes
    final eyePaint = Paint()..color = Colors.black;
    canvas.drawCircle(Offset(cx - w * 0.05, h * 0.32), 2.6, eyePaint);
    canvas.drawCircle(Offset(cx + w * 0.05, h * 0.32), 2.6, eyePaint);

    // Highlight (fake 3D)
    final highlight = Paint()..color = Colors.white.withOpacity(0.25);
    canvas.drawCircle(Offset(cx - w * 0.04, h * 0.28), w * 0.04, highlight);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
