import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Animated gradient background with floating finance icons + glowing orbs.
/// Mimics the "3D animated" login look from the reference video.
class AnimatedBackground extends StatefulWidget {
  const AnimatedBackground({super.key});

  @override
  State<AnimatedBackground> createState() => _AnimatedBackgroundState();
}

class _AnimatedBackgroundState extends State<AnimatedBackground>
    with TickerProviderStateMixin {
  late final AnimationController _bgCtrl;
  late final AnimationController _floatCtrl;

  final List<_FloatingIcon> _icons = const [
    _FloatingIcon(Icons.currency_rupee, 0.10, 0.15, 34, Color(0xFF00E5A0)),
    _FloatingIcon(Icons.credit_card, 0.82, 0.20, 30, Color(0xFF3B6FE0)),
    _FloatingIcon(Icons.savings, 0.08, 0.72, 32, Color(0xFFFFC857)),
    _FloatingIcon(Icons.trending_up, 0.86, 0.66, 30, Color(0xFF00C9A7)),
    _FloatingIcon(Icons.account_balance_wallet, 0.18, 0.42, 26, Color(0xFF9F7AEA)),
    _FloatingIcon(Icons.pie_chart, 0.78, 0.44, 28, Color(0xFFF56565)),
    _FloatingIcon(Icons.attach_money, 0.28, 0.85, 22, Color(0xFF00E5A0)),
    _FloatingIcon(Icons.qr_code_2, 0.72, 0.86, 24, Color(0xFF3B6FE0)),
  ];

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _bgCtrl,
      builder: (context, _) {
        final t = _bgCtrl.value * 2 * math.pi;
        return Stack(
          fit: StackFit.expand,
          children: [
            // Base gradient
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0A0E27), Color(0xFF162152), Color(0xFF0A0E27)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
            // Animated glow orbs
            _orb(Alignment(math.sin(t) * 0.6, math.cos(t) * 0.4 - 0.3),
                const Color(0xFF3B6FE0), 340),
            _orb(Alignment(math.cos(t) * 0.7, math.sin(t) * 0.5 + 0.4),
                const Color(0xFF00C9A7), 300),
            _orb(Alignment(math.sin(t + 1.5) * 0.4, math.cos(t + 1.5) * 0.6),
                const Color(0xFF9F7AEA), 260),
            // Frosted overlay
            Container(color: Colors.black.withOpacity(0.15)),
            // Floating finance icons
            ..._icons.map((icon) => _buildFloatingIcon(icon)),
          ],
        );
      },
    );
  }

  Widget _orb(Alignment align, Color color, double size) {
    return Align(
      alignment: align,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color.withOpacity(0.55), color.withOpacity(0.0)],
          ),
        ),
      ),
    );
  }

  Widget _buildFloatingIcon(_FloatingIcon icon) {
    return AnimatedBuilder(
      animation: _floatCtrl,
      builder: (context, _) {
        final dy = math.sin((_floatCtrl.value * 2 * math.pi) +
                (icon.xFrac + icon.yFrac) * 4) *
            10;
        return Align(
          alignment: Alignment(icon.xFrac * 2 - 1, icon.yFrac * 2 - 1),
          child: Transform.translate(
            offset: Offset(0, dy),
            child: Container(
              width: icon.size + 20,
              height: icon.size + 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: icon.color.withOpacity(0.15),
                border: Border.all(color: icon.color.withOpacity(0.4)),
                boxShadow: [
                  BoxShadow(
                    color: icon.color.withOpacity(0.4),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Icon(icon.icon, color: icon.color, size: icon.size * 0.7),
            ),
          ),
        );
      },
    );
  }
}

class _FloatingIcon {
  final IconData icon;
  final double xFrac;
  final double yFrac;
  final double size;
  final Color color;
  const _FloatingIcon(this.icon, this.xFrac, this.yFrac, this.size, this.color);
}
