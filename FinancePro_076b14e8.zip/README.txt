FinancePro — Login Screen (Flutter)
===================================

Project Structure:
  lib/
    main.dart                       — App entry, Material 3 dark theme
    screens/
      splash_screen.dart            — Animated logo splash (2.6s)
      login_screen.dart             — Main login (glassmorphism + 3D char)
      register_screen.dart          — Register (first user = Admin)
    widgets/
      animated_background.dart      — Gradient + glow orbs + floating icons
      character_3d.dart             — 3D-look business character (CustomPaint)
  pubspec.yaml                      — Dependencies
  preview/index.html                — HTML mockup for visual reference

How to run:
  1. Create a new Flutter project:  flutter create financepro
  2. Replace lib/  and  pubspec.yaml  with these files
  3. flutter pub get
  4. flutter run           (dev)
     flutter build apk     (release APK)

Design Highlights (matches reference video):
  - Deep-blue animated 3D background with moving glow orbs
  - Floating finance icons: ₹, card, coin, chart, wallet, wallet, bank
  - Glassmorphism form card (BackdropFilter blur)
  - Business man 3D character (CustomPaint — no asset needed)
  - Material 3 + Poppins font + gradient buttons
  - Splash → Login → Register / Dashboard
  - Fingerprint + Face ID biometric buttons (stub)
  - Footer: © 2026 FinancePro Manager | Developed by Rahul Patil | v1.0

Notes:
  * For a real high-fidelity 3D character, drop a PNG/Lottie into
    assets/images/character.png and replace Character3D widget with
    Image.asset('assets/images/character.png').
  * First registered user auto-becomes Admin (implement in DB layer).
  * SQLite/shared_preferences dependencies already declared in pubspec.
